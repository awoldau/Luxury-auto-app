# Luxury Auto — Module 1: Authentication & App Setup

A professional Flutter car-rental app, built module by module. This first
delivery contains the full project skeleton, the black-and-gold luxury
theme, and a complete, working authentication flow.

## What's included in Module 1

- **Project structure** — Clean Architecture–flavored MVVM: `core/` (theme,
  routing, shared widgets, utils) and `features/` (one folder per module).
- **Theme** — `core/theme/app_colors.dart` + `app_theme.dart`: black
  backgrounds, gold (`#D4AF37`) accents, Playfair Display headings /
  Poppins body text via `google_fonts`.
- **Screens**: Splash, Onboarding (3 pages), Login, Register, Forgot
  Password, OTP Verification, Reset Password.
- **State management**: `provider` package. `AuthProvider` (ChangeNotifier)
  is the ViewModel; `AuthService` isolates all Firebase calls.
- **Reusable widgets**: `CustomButton`, `CustomTextField`, `GradientBackground`,
  `AppLogo`.
- **Routing**: named routes via `onGenerateRoute` with custom fade/slide
  transitions, in `core/routes/`.

## Project structure

```
lib/
  main.dart                    # entry point, Firebase init
  app.dart                     # MaterialApp, theme, Provider setup
  firebase_options.dart        # PLACEHOLDER — replace via flutterfire configure
  core/
    theme/                     # colors + ThemeData
    constants/                 # app_strings.dart
    routes/                    # route names + generator
    utils/                     # validators
    widgets/                   # shared UI components
  features/
    splash/
    onboarding/
    auth/
      data/auth_service.dart       # Firebase Auth + Firestore calls
      provider/auth_provider.dart  # ViewModel (ChangeNotifier)
      view/                        # screens
```

## Setup

1. **Install dependencies**
   ```
   flutter pub get
   ```

2. **Connect Firebase** (required before running):
   ```
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   This overwrites the placeholder `lib/firebase_options.dart` with your
   real project keys, and registers the Android/iOS apps for you. In the
   Firebase console, enable:
   - **Authentication → Sign-in method → Email/Password**
   - **Cloud Firestore** (start in test mode for development)
   - **Storage** (needed by later modules for car images, license uploads)

3. **OTP verification** — this build ships with an in-app 6-digit OTP UI
   designed to read a code from a Firestore `otp_codes/{email}` document
   (`code`, `expiresAt`). Wire this up with either:
   - A Cloud Function triggered on `sendForgotPasswordOtp` that emails/SMS's
     a code and writes it to that collection, or
   - Firebase Auth's built-in email link flow (already stubbed in
     `AuthService.sendPasswordResetOtp`) if you'd rather skip custom OTP.

4. **Run**
   ```
   flutter run
   ```

## Roadmap — upcoming modules

| Module | Screens |
|---|---|
| 2 — Home | Dashboard, Search, Filter, Categories, Car Details, Gallery, Reviews, Favorites |
| 3 — Booking | Date/Time, Pickup/Drop-off, Summary, Payment (Stripe/PayPal), Confirmation, History |
| 4 — Profile | Profile, Edit Profile, License Upload, Notifications, Settings, Help, About, Privacy |
| 5 — Admin | Admin Login, Dashboard, Manage Cars/Bookings/Users, Reports, Revenue Analytics |
| 6 — Extra | Wallet, Coupons, Referral, Live Map, Chat Support, Car Tracking |

Say the word and I'll generate Module 2 (Home) next, wired into this same
project so everything stays consistent and runnable.
