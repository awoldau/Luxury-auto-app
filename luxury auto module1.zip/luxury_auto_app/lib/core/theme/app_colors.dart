import 'package:flutter/material.dart';

/// Centralized color palette for the Luxury Auto app.
/// Theme: deep black backgrounds with rich gold accents.
class AppColors {
  AppColors._();

  // Core brand colors
  static const Color primaryBlack = Color(0xFF0A0A0A);
  static const Color richBlack = Color(0xFF121212);
  static const Color surfaceBlack = Color(0xFF1C1C1E);
  static const Color cardBlack = Color(0xFF1F1F22);

  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFF4E5B2);
  static const Color goldDark = Color(0xFFA67C00);

  static const Gradient goldGradient = LinearGradient(
    colors: [Color(0xFFBF953F), Color(0xFFFCF6BA), Color(0xFFB38728), Color(0xFFFBF5B7)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const Gradient darkGradient = LinearGradient(
    colors: [Color(0xFF0A0A0A), Color(0xFF1C1C1E)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  // Text
  static const Color textPrimary = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color textMuted = Color(0xFF757575);

  // Utility
  static const Color success = Color(0xFF3DDC84);
  static const Color error = Color(0xFFE53935);
  static const Color warning = Color(0xFFFFB300);
  static const Color divider = Color(0xFF2A2A2C);
  static const Color inputFill = Color(0xFF19191B);
  static const Color white = Color(0xFFFFFFFF);
}
