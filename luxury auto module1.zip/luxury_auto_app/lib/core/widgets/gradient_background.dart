import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Wraps a screen body in the app's signature deep-black gradient,
/// with a subtle gold glow accent in the top corner.
class GradientBackground extends StatelessWidget {
  final Widget child;
  final bool showGlow;

  const GradientBackground({super.key, required this.child, this.showGlow = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.darkGradient),
      child: Stack(
        children: [
          if (showGlow)
            Positioned(
              top: -80,
              right: -60,
              child: Container(
                width: 220,
                height: 220,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.gold.withOpacity(0.08),
                ),
              ),
            ),
          SafeArea(child: child),
        ],
      ),
    );
  }
}
