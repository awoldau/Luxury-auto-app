import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';

/// The Luxury Auto monogram logo: a gold-ringed circle with a car icon,
/// used on the splash screen and auth headers.
class AppLogo extends StatelessWidget {
  final double size;
  final bool showTagline;

  const AppLogo({super.key, this.size = 96, this.showTagline = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.gold, width: 1.6),
            gradient: RadialGradient(
              colors: [AppColors.gold.withOpacity(0.15), Colors.transparent],
            ),
          ),
          child: Icon(Icons.directions_car_filled_rounded, color: AppColors.gold, size: size * 0.45),
        ),
        const SizedBox(height: 16),
        Text(
          'LUXURY AUTO',
          style: GoogleFonts.playfairDisplay(
            color: AppColors.textPrimary,
            fontSize: size * 0.22,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
          ),
        ),
        if (showTagline) ...[
          const SizedBox(height: 6),
          Text(
            'DRIVE THE EXTRAORDINARY',
            style: GoogleFonts.poppins(
              color: AppColors.gold,
              fontSize: size * 0.09,
              letterSpacing: 2,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ],
    );
  }
}
