/// Central registry of named routes. Add new module routes here as
/// Home, Booking, Profile, and Admin modules are generated.
class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String otpVerification = '/otp-verification';
  static const String resetPassword = '/reset-password';

  // Placeholder — Home Dashboard lands here once Module 2 is generated.
  static const String home = '/home';
}
