import 'package:flutter/material.dart';
import '../../features/splash/splash_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/auth/view/login_screen.dart';
import '../../features/auth/view/register_screen.dart';
import '../../features/auth/view/forgot_password_screen.dart';
import '../../features/auth/view/otp_verification_screen.dart';
import '../../features/auth/view/reset_password_screen.dart';
import 'app_routes.dart';

/// Generates routes for the app's Navigator, including typed argument
/// passing for screens like OTP Verification and Reset Password.
class RouteGenerator {
  RouteGenerator._();

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.splash:
        return _build(const SplashScreen(), settings);

      case AppRoutes.onboarding:
        return _build(const OnboardingScreen(), settings);

      case AppRoutes.login:
        return _build(const LoginScreen(), settings);

      case AppRoutes.register:
        return _build(const RegisterScreen(), settings);

      case AppRoutes.forgotPassword:
        return _build(const ForgotPasswordScreen(), settings);

      case AppRoutes.otpVerification:
        final args = settings.arguments as Map<String, dynamic>? ?? {};
        return _build(
          OtpVerificationScreen(
            email: args['email'] as String? ?? '',
            fromForgotPassword: args['fromForgotPassword'] as bool? ?? false,
          ),
          settings,
        );

      case AppRoutes.resetPassword:
        final args = settings.arguments as Map<String, dynamic>? ?? {};
        return _build(
          ResetPasswordScreen(email: args['email'] as String? ?? ''),
          settings,
        );

      case AppRoutes.home:
        // Home Dashboard is generated in Module 2. Temporary placeholder so
        // the auth flow is fully navigable and testable right now.
        return _build(const _HomePlaceholder(), settings);

      default:
        return _build(
          Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
          settings,
        );
    }
  }

  static Route<dynamic> _build(Widget page, RouteSettings settings) {
    return PageRouteBuilder(
      settings: settings,
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (_, animation, __) => page,
      transitionsBuilder: (_, animation, __, child) => FadeTransition(
        opacity: animation,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero).animate(animation),
          child: child,
        ),
      ),
    );
  }
}

class _HomePlaceholder extends StatelessWidget {
  const _HomePlaceholder();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text(
          'Home Dashboard\n(Module 2)',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
