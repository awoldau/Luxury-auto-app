class AppStrings {
  AppStrings._();

  static const String appName = 'Luxury Auto';
  static const String appTagline = 'Drive the Extraordinary';

  // Onboarding
  static const String onboardTitle1 = 'Premium Fleet';
  static const String onboardDesc1 = 'Explore an exclusive collection of the world\'s finest luxury and sports cars.';
  static const String onboardTitle2 = 'Book in Seconds';
  static const String onboardDesc2 = 'Reserve your dream car with just a few taps — anytime, anywhere.';
  static const String onboardTitle3 = 'Doorstep Delivery';
  static const String onboardDesc3 = 'Sit back and relax while we bring your car straight to your location.';
  static const String skip = 'Skip';
  static const String next = 'Next';
  static const String getStarted = 'Get Started';

  // Auth
  static const String login = 'Login';
  static const String register = 'Register';
  static const String welcomeBack = 'Welcome Back';
  static const String loginSubtitle = 'Sign in to continue your luxury journey';
  static const String createAccount = 'Create Account';
  static const String registerSubtitle = 'Join Luxury Auto and drive in style';
  static const String email = 'Email Address';
  static const String password = 'Password';
  static const String confirmPassword = 'Confirm Password';
  static const String fullName = 'Full Name';
  static const String phoneNumber = 'Phone Number';
  static const String forgotPassword = 'Forgot Password?';
  static const String dontHaveAccount = "Don't have an account? ";
  static const String alreadyHaveAccount = 'Already have an account? ';
  static const String signUp = 'Sign Up';
  static const String signIn = 'Sign In';
  static const String rememberMe = 'Remember me';
  static const String orContinueWith = 'Or continue with';
  static const String agreeToTerms = 'I agree to the Terms of Service and Privacy Policy';

  static const String forgotPasswordTitle = 'Forgot Password';
  static const String forgotPasswordSubtitle = 'Enter your registered email to receive a verification code';
  static const String sendCode = 'Send Code';

  static const String otpTitle = 'OTP Verification';
  static const String otpSubtitle = 'Enter the 6-digit code sent to';
  static const String verify = 'Verify';
  static const String resendCode = "Didn't receive the code? ";
  static const String resend = 'Resend';

  static const String resetPasswordTitle = 'Reset Password';
  static const String resetPasswordSubtitle = 'Create a new password for your account';
  static const String newPassword = 'New Password';
  static const String resetPassword = 'Reset Password';
}
