import 'package:flutter/material.dart';
import '../../core/constants/app_strings.dart';

class OnboardingModel {
  final String title;
  final String description;
  final IconData icon;

  const OnboardingModel({required this.title, required this.description, required this.icon});

  static const List<OnboardingModel> pages = [
    OnboardingModel(
      title: AppStrings.onboardTitle1,
      description: AppStrings.onboardDesc1,
      icon: Icons.directions_car_filled_rounded,
    ),
    OnboardingModel(
      title: AppStrings.onboardTitle2,
      description: AppStrings.onboardDesc2,
      icon: Icons.bolt_rounded,
    ),
    OnboardingModel(
      title: AppStrings.onboardTitle3,
      description: AppStrings.onboardDesc3,
      icon: Icons.local_shipping_rounded,
    ),
  ];
}
