import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// A thin wrapper around FirebaseAuth + Firestore for all authentication
/// related operations. Kept separate from the Provider (ViewModel) layer
/// so the UI never talks to Firebase directly — this is the "Model"
/// layer in the MVVM / Clean Architecture split.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Registers a new user with email & password, then creates their
  /// profile document in the `users` collection.
  Future<User?> registerWithEmail({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );

    await credential.user?.updateDisplayName(name.trim());

    await _firestore.collection('users').doc(credential.user!.uid).set({
      'uid': credential.user!.uid,
      'name': name.trim(),
      'email': email.trim(),
      'phone': phone.trim(),
      'photoUrl': null,
      'role': 'customer',
      'createdAt': FieldValue.serverTimestamp(),
    });

    return credential.user;
  }

  Future<User?> loginWithEmail({required String email, required String password}) async {
    final credential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    return credential.user;
  }

  Future<void> sendPasswordResetOtp({required String email}) async {
    // Firebase's built-in flow sends a reset *link*, not an OTP. For an
    // in-app 6-digit OTP experience (as designed), pair this with a
    // Cloud Function / Firestore-backed OTP document keyed by email.
    // The stub below keeps the standard Firebase link flow available too.
    await _auth.sendPasswordResetEmail(email: email.trim());
  }

  /// Verifies a 6-digit code against the `otp_codes` collection.
  /// Expects a Cloud Function to have written a hashed/plain code there
  /// when [sendPasswordResetOtp] (or an SMS-based equivalent) was called.
  Future<bool> verifyOtp({required String email, required String code}) async {
    final doc = await _firestore.collection('otp_codes').doc(email.trim()).get();
    if (!doc.exists) return false;
    final data = doc.data();
    if (data == null) return false;

    final storedCode = data['code'] as String?;
    final expiresAt = (data['expiresAt'] as Timestamp?)?.toDate();

    if (storedCode == null || expiresAt == null) return false;
    if (DateTime.now().isAfter(expiresAt)) return false;

    return storedCode == code;
  }

  Future<void> resetPassword({required String email, required String newPassword}) async {
    // Completing a password reset for another user out-of-band requires
    // Firebase Admin SDK (Cloud Function). This client-side call updates
    // the *currently signed-in* user's password when applicable.
    final user = _auth.currentUser;
    if (user != null && user.email == email.trim()) {
      await user.updatePassword(newPassword);
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
  }

  String mapFirebaseError(Object error) {
    if (error is FirebaseAuthException) {
      switch (error.code) {
        case 'email-already-in-use':
          return 'An account already exists with this email.';
        case 'invalid-email':
          return 'Please enter a valid email address.';
        case 'weak-password':
          return 'Your password is too weak.';
        case 'user-not-found':
          return 'No account found with this email.';
        case 'wrong-password':
        case 'invalid-credential':
          return 'Incorrect email or password.';
        case 'too-many-requests':
          return 'Too many attempts. Please try again later.';
        case 'network-request-failed':
          return 'Network error. Check your connection.';
        default:
          return error.message ?? 'Something went wrong. Please try again.';
      }
    }
    return 'Something went wrong. Please try again.';
  }
}
