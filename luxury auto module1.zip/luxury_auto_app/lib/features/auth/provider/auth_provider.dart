import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../data/auth_service.dart';

enum AuthStatus { idle, loading, success, error }

/// ViewModel for the authentication module. Screens read state (isLoading,
/// errorMessage) and call methods here; this class is the only thing that
/// talks to [AuthService].
class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  AuthStatus _status = AuthStatus.idle;
  String? _errorMessage;
  User? _user;
  String? _pendingResetEmail;

  AuthStatus get status => _status;
  bool get isLoading => _status == AuthStatus.loading;
  String? get errorMessage => _errorMessage;
  User? get user => _user;
  String? get pendingResetEmail => _pendingResetEmail;
  bool get isLoggedIn => _authService.currentUser != null;

  void _setLoading() {
    _status = AuthStatus.loading;
    _errorMessage = null;
    notifyListeners();
  }

  void _setError(Object error) {
    _status = AuthStatus.error;
    _errorMessage = _authService.mapFirebaseError(error);
    notifyListeners();
  }

  void _setSuccess() {
    _status = AuthStatus.success;
    _errorMessage = null;
    notifyListeners();
  }

  void _setCustomError(String message) {
    _status = AuthStatus.error;
    _errorMessage = message;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  Future<bool> login({required String email, required String password}) async {
    _setLoading();
    try {
      _user = await _authService.loginWithEmail(email: email, password: password);
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e);
      return false;
    }
  }

  Future<bool> register({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    _setLoading();
    try {
      _user = await _authService.registerWithEmail(
        name: name,
        email: email,
        phone: phone,
        password: password,
      );
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e);
      return false;
    }
  }

  Future<bool> sendForgotPasswordOtp({required String email}) async {
    _setLoading();
    try {
      await _authService.sendPasswordResetOtp(email: email);
      _pendingResetEmail = email;
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e);
      return false;
    }
  }

  Future<bool> verifyOtp({required String email, required String code}) async {
    _setLoading();
    try {
      final isValid = await _authService.verifyOtp(email: email, code: code);
      if (!isValid) {
        _setCustomError('Invalid or expired code. Please try again.');
        return false;
      }
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e);
      return false;
    }
  }

  Future<bool> resendOtp({required String email}) async {
    return sendForgotPasswordOtp(email: email);
  }

  Future<bool> resetPassword({required String email, required String newPassword}) async {
    _setLoading();
    try {
      await _authService.resetPassword(email: email, newPassword: newPassword);
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e);
      return false;
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    notifyListeners();
  }
}
